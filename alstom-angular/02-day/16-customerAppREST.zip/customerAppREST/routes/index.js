var express = require('express');
var customerService = require('../service/customer-service');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  //res.render('index', { title: 'Customer App' });
  res.redirect("/login");
});

router.get('/dashboard', function(req, res, next) {
  res.render('index', { title: 'Dashboard' });
});

router.get('/about', function(req, res, next) {
  res.render('index', { title: 'About' });
});

router.get('/customer', function(req, res, next) {
  res.render('customers', { title: 'Customers',data:customerService.getCustomers()});
});

router.get('/customer/add', function(req, res, next) {
  res.render('add-customer', { title: 'Add Customer' });
});

//   /api/customer
router.get('/customer/:field/:searchTxt', function(req, res, next) {
  res.render('customers', { title: 'Customers',data:customerService.searchCustomer(req.params.field, req.params.searchTxt)});
});

router.get('/customer/edit/:id', function(req, res, next) {
  res.render('edit-customer', { title: 'Update Customer',customer:customerService.getCustomerById(req.params.id)});
});

router.get('/login', function(req, res, next) {
  res.render('login', { title: 'Customer App' });
});

module.exports = router;
