var express = require('express');
var router = express.Router();
var customerService = require('../service/customer-service');

// /api
router.get('/', function(req, res, next) {
  res.send('api url is  /');
});

//   /api/customer
router.get('/customer', function(req, res, next) {
  res.send(customerService.getCustomers());
});

//   /api/customer
router.get('/customer/:field/:searchTxt', function(req, res, next) {
  res.send(customerService.searchCustomer(req.params.field, req.params.searchTxt));
});

//   /api/customer/:id
router.get('/customer/:id', function(req, res, next) {
  res.send(customerService.getCustomerById(req.params.id));
});

//   post /api/customer
router.post('/customer', function(req, res, next) {
  res.send(customerService.addCustomer(req.body));
});

//   delete /api/customer
router.delete('/customer', function(req, res, next) {
  res.send(customerService.deleteCustomer(req.body.id));
});


//  put /api/customer
router.put('/customer', function(req, res, next) {
  res.send(customerService.updateCustomer(req.body));
});

module.exports = router;
