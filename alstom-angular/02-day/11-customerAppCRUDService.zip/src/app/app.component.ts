import { Component } from '@angular/core';

@Component({
  selector: 'app-root', // selector >> Sachin  <app-root></app-root>
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'helloApp';
  doLogin= () =>{
    alert("Hello login");
  }
}

//One component has minimum
// CSS
// ts // jscode 
// html 
// spec.ts