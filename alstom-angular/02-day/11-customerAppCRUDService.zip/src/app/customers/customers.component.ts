import { Component, OnInit } from '@angular/core';
import {Customer} from "../customer"
import {CustomerService} from '../customer.service'
import { Router } from '@angular/router';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit {
  
  customers:Customer[] = [];
  constructor(private router: Router, private customerService:CustomerService ) {
    this.customers = customerService.getCustomerList();
 }
  buttonLabel:string = "Add";

  customer = {
    id:0, name:'',email:'',phone:'',address:''
  }
  /*
  customers = [
    {id:1,name:'Vivek',email:'vivek@abc.com',phone:'2356422433', address:'India'},
    {id:2,name:'Pratistha',email:'pari@abc.com',phone:'28896422433', address:'India'},
    {id:3,name:'Samridh',email:'samar@abc.com',phone:'2889rr22433', address:'India'},
    {id:4,name:'Vishal',email:'vishal@abc.com',phone:'28899822433', address:'India'}
  ];*/

  selectCustomerId:number = 78;
    updateCustomer(customer:Customer){
      if(customer.id == 0 ){
        this.customerService.customerAdd(customer);
      }else{ 
        this.customerService.updateCustomer(customer);
      }

      console.log("customer id @parent "+customer.id);
      console.log("new customer name is "+customer.name);
      this.resetCustomer();
    }

  resetCustomer(){
    console.log(">>resetCustomer")
    this.buttonLabel = "Add";
    this.customer = {
      id:0, name:'',email:'',phone:'',address:''
    }
  }

  deleteCustomer(id:number){
    console.log(">> deleteCustomer "+id)
    //this.customers = this.customers.filter((record)=>(record.id != id))
    this.customerService.deleteCustomer(id);
    this.customers = this.customerService.getCustomerList();
  }
  customerDetails(id:number){
    this.selectCustomerId = id;
    this.buttonLabel = "Update"; // Button value = "Update"
    let customerList = this.customers.filter((record)=>(record.id == id))
    if(customerList.length > 0){
      // object is pointer (same object)
      // this.customer = customerList[0]; //this will show record to form
      // object copy 
      this.customer = {...customerList[0]}; 
    }
    console.log(">> customerDetails ")
  }

  ngOnInit(): void {
    console.log("On init of Customer Comp")
  }
}
