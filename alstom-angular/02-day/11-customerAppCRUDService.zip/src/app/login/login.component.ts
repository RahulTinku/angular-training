import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  heading:string = "Login";
  constructor(private router: Router) { }
  
  user = {
  	username:"test",
  	password:"test",
  }

  username:string = "";

  ngOnInit(): void {
  }

  doLogin(){
    let a:string = '47';
    let b:number = 100; 
    console.log("Value of a= "+a);
   if(this.user.username == this.user.password){
     this.router.navigate(['/customers']);
     //alert('Login Success');
   }else{
     alert('Login Failed');
   }
 }
}
