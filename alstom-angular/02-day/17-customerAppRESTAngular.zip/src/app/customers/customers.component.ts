import { Component, OnInit } from '@angular/core';
import {Customer} from "../customer"
import {CustomerService} from '../customer.service'
import { Router } from '@angular/router';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit {
  
  customers:Customer[] = [];
  constructor(private router: Router, private customerService:CustomerService ) {
    //this.customers = customerService.getCustomerList();
    //this.reloadData();
 }
  buttonLabel:string = "Add";

  reloadData() {
    this.customerService.getCustomerListRest().subscribe((data )=>{
    	this.customers = data;
    });
  }

  customer = {
    id:0, name:'',email:'',phone:'',address:''
  }
  selectCustomerId:number = 78;

    updateCustomer(customer:Customer){
      if(customer.id == 0 ){
        //this.customerService.customerAdd(customer);
        this.customerService.createCustomerRest(customer).subscribe(()=>{
          this.resetCustomer();
          this.reloadData();
        })
      }else{ 
        this.customerService.updateCustomerRest(customer).subscribe(()=>{
          this.resetCustomer();
          this.reloadData();
        })
      }
      //console.log("customer id @parent "+customer.id);
      //console.log("new customer name is "+customer.name); 
    }

    goAddCustomer(){
      this.router.navigate(['/add-customer']);
    }

  resetCustomer(){
    this.buttonLabel = "Add";
    this.customer = {
      id:0, name:'',email:'',phone:'',address:''
    }
  }

  deleteCustomer(id:any){
    console.log(">> deleteCustomer ::"+id)
    //this.customers = this.customers.filter((record)=>(record.id != id))
    //this.customerService.deleteCustomer(id);
    //this.customers = this.customerService.getCustomerList();
    let customer:Customer = new Customer();
    customer.id= id;

    this.customerService.deleteCustomerRest(customer).subscribe((data)=>{
      console.log("result",data);
      this.reloadData();
    })
  }
  customerDetails(id:number){
    this.selectCustomerId = id;
    this.buttonLabel = "Update"; // Button value = "Update"
    let customerList = this.customers.filter((record)=>(record.id == id))
    if(customerList.length > 0){
      // object is pointer (same object)
      // this.customer = customerList[0]; //this will show record to form
      // object copy 
      this.customer = {...customerList[0]}; 
    }
    console.log(">> customerDetails ")
  }

  ngOnInit(): void {
    console.log("On init of Customer Comp");
    this.reloadData();
  }
}
