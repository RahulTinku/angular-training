import { Component, OnInit,Input,Output, EventEmitter } from '@angular/core';
import { Customer } from '../customer';

@Component({
  selector: 'app-customer-form',
  templateUrl: './customer-form.component.html',
  styleUrls: ['./customer-form.component.css']
})
export class CustomerFormComponent implements OnInit {
  // input coming from parent , here it is selectId 
  constructor() { }
  buttonLabel = "Add";
  addCustomer (){

  }
  resetCustomer(){

  }
  @Input() selectId: any = 0;
  @Input() selectCustomer: Customer =  {
    id:0, name:'',email:'',phone:'',address:''
  }
  // output function coming from parent , here it is doUpdate 
  @Output() doUpdate = new EventEmitter<Customer>();

  updateRequest(){
    console.log("customer::",this.selectCustomer);
  	//var customer:Customer = new Customer();
  	//customer.name = name; //'Rama'
  	// customer.id = this.selectId;
  	this.doUpdate.emit(this.selectCustomer);
  }
  ngOnInit() {
  }
}