import { Component, OnInit } from '@angular/core';
import {Customer} from "../customer"
import {CustomerService} from '../customer.service'
import { Router,ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-update-customer',
  templateUrl: './update-customer.component.html',
  styleUrls: ['./update-customer.component.css']
})
export class UpdateCustomerComponent implements OnInit {

  constructor(private route: ActivatedRoute,private router: Router, private customerService:CustomerService ) {
    //this.customers = customerService.getCustomerList();
 }
  id:any = 0;
  buttonLabel:string = "Update";

  customer = {
    id:0, name:'',email:'',phone:'',address:''
  }

  selectCustomerId:number = 0;

    updateCustomer(customer:Customer){
      console.log("updateCustomer...");
      if(customer.id == 0 ){
        this.customerService.createCustomerRest(customer).subscribe(()=>{
          this.router.navigate(['/customers']);
        })
      }else{ 
        //this.customerService.updateCustomer(customer);
        this.customerService.updateCustomerRest(customer).subscribe(()=>{
          this.router.navigate(['/customers']);
        })
      }
      console.log("customer id @parent "+customer.id);
      console.log("new customer name is "+customer.name);
      
    }

    goAddCustomer(){
      this.router.navigate(['/add-customer']);
    }

  resetCustomer(){
    console.log(">>resetCustomer")
    this.buttonLabel = "Add";
    this.customer = {
      id:0, name:'',email:'',phone:'',address:''
    }
  }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
    console.log("this.id ::"+this.id );
    this.customerService.getCustomerRest(this.id).subscribe(
      (customer)=>{
        this.customer = customer;
    });
  }
}
