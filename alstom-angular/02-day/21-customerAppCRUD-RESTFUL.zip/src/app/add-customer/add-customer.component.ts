import { Component, OnInit } from '@angular/core';
import {Customer} from "../customer"
import {CustomerService} from '../customer.service'
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html',
  styleUrls: ['./add-customer.component.css']
})
export class AddCustomerComponent implements OnInit {

  constructor(private router: Router, private customerService:CustomerService ) {
    //this.customers = customerService.getCustomerList();
 }
  buttonLabel:string = "Add";

  customer = {
    id:0, name:'',email:'',phone:'',address:''
  }

  selectCustomerId:number = 0;
  updateCustomer(customer:Customer){
    console.log("updateCustomer...");
    if(customer.id == 0 ){
      this.customerService.createCustomerRest(customer).subscribe(()=>{
        this.router.navigate(['/customers']);
      })
    }else{ 
      //this.customerService.updateCustomer(customer);
      this.customerService.updateCustomerRest(customer).subscribe(()=>{
        this.router.navigate(['/customers']);
      })
    }
    console.log("customer id @parent "+customer.id);
    console.log("new customer name is "+customer.name);
    
  }
    goAddCustomer(){
      this.router.navigate(['/add-customer']);
    }

  resetCustomer(){
    console.log(">>resetCustomer")
    this.buttonLabel = "Add";
    this.customer = {
      id:0, name:'',email:'',phone:'',address:''
    }
  }

  ngOnInit(): void {
  }
}
