import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { CustomersComponent } from './customers/customers.component';
import { MenuComponent } from './menu/menu.component';
import { CustomerFormComponent } from './customer-form/customer-form.component';

@NgModule({ //module 
  declarations: [
    AppComponent, // declare all comp
    LoginComponent, 
    DashboardComponent,
     AboutusComponent, CustomersComponent, 
     MenuComponent, CustomerFormComponent
  ],
  imports: [  // import other modules
    BrowserModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [], // provides is fro service 
  bootstrap: [AppComponent] // init these components
})
export class AppModule { }
